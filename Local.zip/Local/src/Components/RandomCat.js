import React from 'react'

const RandomCat = () => {
  return (
    <div>
      hello
    </div>
  )
}

export default RandomCat
