import React from 'react'
// import Folllow_blog from './Folllow_blog'

const Home = () => {
  return (
    <div>
      {/* <Folllow_blog/> */}
    </div>
  )
}

export default Home
