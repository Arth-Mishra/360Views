import React from 'react'
import '../css/Body.css'

const Body = () => {
  return (
    <>
    <div className="container">
    </div>
    </>
  )
}

export default Body
